# This class is now implemented in C
